var bName = navigator.appName;
var bVer = parseInt(navigator.appVersion);
var ok=false;

if      (bName == "Netscape" && bVer >= 4) ok=true;
else if (bName == "Netscape" && bVer == 3) ok=true;
else if (bName == "Microsoft Internet Explorer" && bVer >= 4) ok=true;
else if (bName == "Microsoft Internet Explorer") ok=false;
else br = ok=false;

function swap(image1,image2) {
	if (ok == true) {
		image1.src=image2.src;
	}

}

// If browser is equivalent to Netscape 3 or better.
if (ok == true) {
	var animal=new Image();
	animal.src='squrirel4.jpg';

	var blank_image=new Image();
	blank_image.src='blank.gif';
}

var piece;

function set_piece() {
	var last_piece=piece;
	
	while(piece==last_piece)
		piece=Math.floor(Math.random()*4)+1;

	if(piece==1)
		swap(document.A,animal);

	if(piece==2)
		swap(document.B,animal);

	if(piece==3)
		swap(document.C,animal);

	if(piece==4)
		swap(document.D,animal);

}

function check_piece(p,i) {

	if(p == piece) {
		if(ok) swap(i,blank_image);
		set_piece();		
	}

}

function right_click(e,p,i) {

	if (navigator.appName == 'Netscape' && 
	(e.which == 3 || e.which == 2)){
		check_piece(p,i);
		return true;
	}
	else if (navigator.appName == 'Microsoft Internet Explorer' && 
	(event.button == 2 || event.button == 3)) {
		check_piece(p,i);	
		return true;
	}
	return false;
}